package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuringJobAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuringJobAppApplication.class, args);
	}

}
